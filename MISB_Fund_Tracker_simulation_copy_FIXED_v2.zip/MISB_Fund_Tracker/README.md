# MISB Fund Management Tracker

Local Cofundr workspace for managing the MISB portfolio from the transaction ledger, current simulation report and legacy MIDAS projection model.

## Start on Windows
Double-click `start.bat`, then open `http://127.0.0.1:5055`.

## Main views
- **Fund Overview** — cash available, total investment committed, outstanding principal, upcoming receipts and management alerts.
- **Issuer Exposure** — RM2.0m default issuer cap, utilisation, headroom and allocatable amount.
- **Receivables** — exact-date principal receipts.
- **Profit Analytics** — month-on-month expected vs paid profit, quarterly return, total return since inception, and note-level repayment schedule.
- **Active Portfolio** — click a note to tick/adjust paid items and actual payment dates.
- **Account & Ledger** — actual wallet movements and balance breakdown.
- **Cash Projection** — projected account balance by date from future receivables and planned allocations.
- **MISB Reports** — bi-weekly fund monitoring report plus monthly account-statement generator.
- **Data Sources** — refresh transaction ledger, simulation report, and historical MIDAS projections.

## Source priority
The transaction ledger is the primary source for actual cash movements and payments. The historical MIDAS projection workbook is used only to backfill realised older repayment periods when a matching ledger receipt is absent.

## Historical MIDAS logic
The legacy daily model follows: `Closing Balance = Opening Balance + Cash In - Cash Out`. Its realised cash-in rows are used for historical repayment backfill through the last historical `as at` month in the workbook.

## Returns
- **Return this quarter** = successful Profit Payouts in the current calendar quarter / RM10,000,000.
- **Total returns** = successful Profit Payouts since inception / RM10,000,000.

## Monthly account statement
The statement is generated directly from successful transaction-log rows for the selected month. Opening and closing balances come from the first/last ledger entry in that month, while total cash in/out is calculated from the actual change between Previous Balance and Current Balance for every transaction.

## Early settlement handling
When full principal is returned before maturity, future contractual periods are closed and the final profit is pro-rated from the last paid instalment date to the actual settlement date using `Outstanding Principal × Monthly Rate × Days / 30`.

## Simulation Copy / MISB bi-weekly template update
The **Simulation Copy** page restores the copy/paste workflow and adds a safer template-preserving export.

1. Import the latest transaction ledger under **Data Sources**.
2. Open **Simulation Copy** and choose the bi-weekly cut-off date.
3. **Copy data rows only** returns the same 36 populated columns as the existing `Query result` sheet for pasting at A2.
4. **Generate updated simulation report** opens the imported simulation workbook as the template and updates transaction-driven repayment fields while retaining the workbook's existing sheets, formatting, formulas and Remarks cells.
5. The tracker updates Loan Status, Paid/Unpaid Principal, Paid/Unpaid Profit, Late Profit/Tawidh, Actual Repayment, Service Fee and early-repayment fields from successful ledger transactions through the chosen cut-off.
6. New ledger allocations that are not yet present in the simulation template are flagged rather than invented, because the transaction log does not contain issuer, tenure, pricing and note-description particulars needed to build a valid new simulation row.
